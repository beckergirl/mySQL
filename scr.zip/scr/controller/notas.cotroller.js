const connection = require("../database")
///comprobar que funciona con los cambios POST MAN

function getNotas(request, response){

    let sql;

    if (request.query.id == null){

        sql = "SELECT * FROM marks";

    }else{

        sql = "SELECT student_id, subject_id, mark FROM marks WHERE student_id=" + request.query.id;
    }
    connection.query(sql, function (err, result){

        if(err){
            
            console.log(err);

        }else{
    
            response.send(result);
        }
    })
}


function postNotas(request, response){

    console.log(request.body);

    let sql = "INSERT INTO marks (student_id, subject_id, mark)" + 
              "VALUES ('" + request.body.student_id + "', '" + 
                            request.body.subject_id + "', '" +
                            request.body.mark + "')";
    console.log(sql);                      
    connection.query(sql, function (err, result){

        if (err){

            console.log(err);

        }else{
  
            console.log(result);

            if(result.insertId){

                response.send(String(result.insertId));
            }else{
                response.send("-1");
            }
        }
    })
}

function putNotas(request, response){

    console.log(request.body);

    let params = [request.body.student_id, 
                  request.body.subject_id, 
                  request.body.mark,
                  request.body.id]

    let sql = "UPDATE marks SET student_id = COALESCE(?, student_id) , " + 
              "subject_id = COALESCE(?, subject_id) , " + 
              "mark = COALESCE(?, mark) WHERE marks.id = ?";

    console.log(sql); 
    connection.query(sql, params,function (err, result){

        if (err) 
            console.log(err);
        else 
        {
            response.send(result);
        }
    })
}

function deleteNotas(request, response){

    console.log(request.body);

    let sql = "DELETE FROM marks WHERE marks.id = '" + request.body.id + "'";

    console.log(sql); 

    connection.query(sql, function (err, result){

        if(err){
            
            console.log(err);

        }else{

            response.send(result);
        }
    })
}


module.exports = { getNotas, postNotas, putNotas, deleteNotas };


