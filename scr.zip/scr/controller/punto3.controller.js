const connection = require("../database")


///Obtiene la nota media del id del alumno:

function getMedia(request, response){ ///este funciona en postman

    let sql;

    if (request.query.id == null){

        sql = "SELECT AVG (mark) AS media FROM marks";

    }else{

        sql = "SELECT AVG (mark) AS media FROM marks WHERE id=" + request.query.id ;
    }
    connection.query(sql, function (err, result){

        if(err){
            
            console.log(err);

        }else{
    
            response.send(result);
        }
    })
}


/* ////lista de las asignaturas a la que están apuntadas el alumno / Devuelve los nombres y apellidos de todos los alumnos y
los nombres de las asignaturas a la que están apuntadas. */

function getApuntadas(request, response){ ///cambia!

    let sql;

    if (request.query.id == null){

        sql = "SELECT first_name, last_name, title FROM students JOIN marks ON (students.id = marks.student_id) JOIN subjects ON (marks.subject_id = subjects.id)";

    }else{

        sql = "SELECT first_name, last_name, title FROM students JOIN marks ON (students.id = marks.student_id) JOIN subjects ON (marks.subject_id = subjects.id) WHERE students.id=" + request.query.id;
    }
     
    connection.query(sql, function (err, result)
    {
        if (err)
            console.log(err);
        else
        {
            response.send(result)
        }    
    })  
}



/* lista de las asignaturas que imparte el profesor / Devuelve los nombres y apellidos de todos los profesores y los nombres de las asignaturas a la que imparten. */

function getImpartidas(request, response){ /// funciona en postman

    let sql;

    if (request.query.id == null){

        sql = "SELECT first_name, last_name, title FROM teachers JOIN subject_teacher on (teachers.id = subject_teacher.teacher_id) JOIN subjects on (subject_teacher.subject_id = subjects.id)";

    }else{

        sql = "SELECT first_name,last_name,title FROM teachers JOIN subject_teacher on (teachers.id = subject_teacher.teacher_id) JOIN subjects on (subject_teacher.subject_id = subjects.id) WHERE teachers.id="+ request.query.id;

    }
    connection.query(sql, function (err, result)
    {
        if (err)
            console.log(err);
        else
        {
            response.send(result);
        }    
    })  
}

module.exports = { getMedia, getApuntadas, getImpartidas };
