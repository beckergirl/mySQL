const connection = require("../database")

function getAlumnos(request, response){

    let sql;

    if (request.query.id == null){

        sql = "SELECT * FROM students";

    }else{

        sql = "SELECT * FROM students WHERE id=" + request.query.id;
    }
    connection.query(sql, function (err, result){

        if(err){
            
            console.log(err);

        }else{
    
            response.send(result);
        }
    })
}

function getAlumnos2(request, response){

    let sql = "SELECT * FROM students WHERE id=" + request.params.id;

    console.log(sql);  

    connection.query(sql, function (err, result){

        if(err){

            console.log(err);
        }else{

            console.log(result)
            response.send(result);
        }
    })
}

function postAlumno(request, response){

    console.log(request.body);

    let sql = "INSERT INTO students (first_name, last_name, email) " + 
              "VALUES ('" + request.body.first_name + "', '" + 
                            request.body.last_name + "', '" +
                            request.body.email + "')";
    console.log(sql);                      
    connection.query(sql, function (err, result){

        if (err){

            console.log(err);

        }else{
  
            console.log(result);

            if(result.insertId){

                response.send(String(result.insertId));
            }else{
                response.send("-1");
            }
        }
    })
}

function putAlumno(request, response){

    console.log(request.body);

    let params = [request.body.first_name, 
                  request.body.last_name, 
                  request.body.email,
                  request.body.id]

    let sql = "UPDATE students SET first_name = COALESCE(?, first_name) , " + 
               "last_name = COALESCE(?, last_name) , " + 
               "email = COALESCE(?, email) WHERE id = ?";

    console.log(sql); 
    connection.query(sql, params,function (err, result){

        if (err) 
            console.log(err);
        else 
        {
            response.send(result);
        }
    })
}

function deleteAlumno(request, response){

    console.log(request.body);

    let sql = "DELETE FROM students WHERE id = '" + request.body.id + "'";

    console.log(sql); 

    connection.query(sql, function (err, result){

        if(err){
            
            console.log(err);

        }else{

            response.send(result);
        }
    })
}


module.exports = {getAlumnos, getAlumnos2, postAlumno, putAlumno, deleteAlumno};

