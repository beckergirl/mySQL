const { Router } = require("express")
const router = Router();
const punto3Ctrl = require("../controller/punto3.controller");

router.get("/punto3/media", punto3Ctrl.getMedia);

router.get("/punto3/apuntadas", punto3Ctrl.getApuntadas);

router.get("/punto3/impartidas", punto3Ctrl.getImpartidas);



module.exports = router;