// paso 2: FICHERO DATABASE.js

const mysql = require("mysql2");

const connection = mysql.createConnection(

    {
        host: "localhost",
        user: "root",
        password : "Escaparate82",
        database: "codenotch2"
    }
);

connection.connect(function(error){

    if(error){

        console.log(error);

    }else{

        console.log("Conexión correcta");
    }
});

module.exports = connection;